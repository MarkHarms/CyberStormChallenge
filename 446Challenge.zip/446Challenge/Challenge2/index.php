<!DOCTYPE html>
<html>
    <header>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<title>OpenLayers - User input to create marker</title>
        <link rel="stylesheet" type="text/css" href="Challenge2.css">	
    </header>
    <body>
        
	<style>
#mapdiv {
    width:800px;
    height:600px;
}
#fileDisplayArea {
  margin-top: 2em;
  width: 100%;
  overflow-x: auto;
}
</style>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	echo "Test";
	session_start();
 	echo $_SESSION['username'];
	if(!isset($_SESSION['username'])){
		header("Location: userlogin.php");
		
	}
	
	$db = mysqli_connect('23.229.173.35','jsl039','Password','projectCSC446')
	 or die('Error connecting to MySQL server.');
	 echo "Test";
	$login = mysqli_query($db,"select * from challengeTable where (Challenge= 1) and (Password = '" . $_POST['password'] . "')");
	$rowcount = mysqli_num_rows($login);
	echo $rowcount;
	if ($rowcount == 1) {
	mysqli_query($db,"Update userloginTable Set Grade = 'C' Where Username = '".$_SESSION['username']."'");
	header("Location: ../Challenge3/");
	}
	else
	{
	header("Location: index.php");
	}
}	
?>
		<pre id="fileDisplayArea"><pre>
        <div>
            <form id="passDiv" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
               <label id="passwordLbl">Password: </label>
                <input type="text" name="password" value="<?php echo $password;?>">
                <input type="submit" name="submit" value="Submit">  
              
            </form>
        </div>
            
    </body>
</html>